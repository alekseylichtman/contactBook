//
//  NewContactViewController.swift
//  Phone_2.0
//
//  Created by Oleksii Kolakovskyi on 10/24/19.
//  Copyright © 2019 Aleksey. All rights reserved.
//

import Foundation
import UIKit

class NewContactViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var lastNameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var notesTextField: UITextView!
    @IBOutlet weak var contactImage: UIImageView!
    
    var contactImagePicked: UIImage? = nil
    
    override func viewDidLoad() {
        contactImage.layer.cornerRadius = 42
        contactImage.image = UIImage.init(named: "defaultavatar")

    }
    
    @IBAction func saveNewContactButtonTapped(_ sender: UIButton) {
        _ = ContactsFormat.addNewContact(firstName: nameTextField.text!,
                                         lastName: lastNameTextField.text!,
                                         number: phoneTextField.text!,
                                         photo: contactImagePicked,
                                         notes: notesTextField.text!)
        print(contacts)
        navigationController?.popViewController(animated: true)
    }
    
    
    
    
    @IBAction func addImageBUttonTapped(_ sender: Any) {
        showAlert()
    }
    
    
    
    func showAlert() {
        
        let alert = UIAlertController(title: "", message: "", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: {(action: UIAlertAction) in
            self.getImage(fromSourceType: .camera) }))
        alert.addAction(UIAlertAction(title: "Photo Album", style: .default, handler: {(action: UIAlertAction) in
            self.getImage(fromSourceType: .photoLibrary) }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel , handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    //get image from source type
    func getImage(fromSourceType sourceType: UIImagePickerController.SourceType) {
        
        //Check is source type available
        
        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
            let imagePickerController = UIImagePickerController()
            imagePickerController.delegate = self
            imagePickerController.sourceType = sourceType
            self.present(imagePickerController, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        contactImagePicked = info[.originalImage] as? UIImage
        contactImage.image = contactImagePicked
        picker.dismiss(animated: true)
    }
}
